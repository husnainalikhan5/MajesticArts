//
//  Constant.swift
//  MajesticArt
//
//  Created by Uzma  Amjad on 16/10/2020.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation


var userDefaults = UserDefaults()
struct Apis {
    static let baseURL = "http://majestic-arts.com/majistic/public/api/"
    static let signUp = "signup"
    static let login = "login"
    static let collections = "collections"
    static let trending_posts = "trending_posts"
    static let tranding_collections = "tranding_collections"
    static let add_favroute = "add_favroute"
    static let post_by_collections = "post_by_collections"
    static let get_favroute = "get_favroute"
    static let collection_posts = "collection_posts"
    static let search_post = "search_post"
    static let update_phone = "update_phone"
    static let forget_password = "forget_password"
    static let slider_post = "slider_post"
}


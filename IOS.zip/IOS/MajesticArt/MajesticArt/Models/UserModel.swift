//
//  UserModel.swift
//  MajesticArt
//
//  Created by Uzma  Amjad on 18/10/2020.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
struct UserModel : Codable {
    let status : Int?
    let message : String?
    let data : UserData?

    enum CodingKeys: String, CodingKey {

        case status = "status"
        case message = "message"
        case data = "data"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        status = try values.decodeIfPresent(Int.self, forKey: .status)
        message = try values.decodeIfPresent(String.self, forKey: .message)
        data = try values.decodeIfPresent(UserData.self, forKey: .data)
    }

}
struct UserData : Codable {
    let id : Int?
    let f_name : String?
    let l_name : String?
    let email : String?
    let reset_token : String?
    let phone : String?

    enum CodingKeys: String, CodingKey {

        case id = "id"
        case f_name = "f_name"
        case l_name = "l_name"
        case email = "email"
        case reset_token = "reset_token"
        case phone = "phone"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        id = try values.decodeIfPresent(Int.self, forKey: .id)
        f_name = try values.decodeIfPresent(String.self, forKey: .f_name)
        l_name = try values.decodeIfPresent(String.self, forKey: .l_name)
        email = try values.decodeIfPresent(String.self, forKey: .email)
        reset_token = try values.decodeIfPresent(String.self, forKey: .reset_token)
        phone = try values.decodeIfPresent(String.self, forKey: .phone)
    }

}


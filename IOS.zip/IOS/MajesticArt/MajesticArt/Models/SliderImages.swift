//
//  SliderImages.swift
//  MajesticArt
//
//  Created by Uzma  Amjad on 18/10/2020.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
struct SliderImages : Codable {
    let status : Int?
    let message : String?
    let data : [String]?

    enum CodingKeys: String, CodingKey {

        case status = "status"
        case message = "message"
        case data = "data"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        status = try values.decodeIfPresent(Int.self, forKey: .status)
        message = try values.decodeIfPresent(String.self, forKey: .message)
        data = try values.decodeIfPresent([String].self, forKey: .data)
    }

}

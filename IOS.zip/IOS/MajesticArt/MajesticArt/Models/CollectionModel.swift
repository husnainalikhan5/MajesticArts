//
//  CollectionModel.swift
//  MajesticArt
//
//  Created by Uzma  Amjad on 17/10/2020.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
struct CollectionModel : Codable {
    let status : Int?
    let message : String?
    let data : [CollectionData]?
}
struct CollectionData : Codable {
    let id : Int?
    let trending : String?
    let name : String?
    let image : String?
}

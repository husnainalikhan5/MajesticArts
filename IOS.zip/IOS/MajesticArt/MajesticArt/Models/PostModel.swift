//
//  PostModel.swift
//  MajesticArt
//
//  Created by Uzma  Amjad on 18/10/2020.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
struct PostModel : Codable {
    let status : Int?
    let message : String?
    var data : [PostData]?

    enum CodingKeys: String, CodingKey {

        case status = "status"
        case message = "message"
        case data = "data"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        status = try values.decodeIfPresent(Int.self, forKey: .status)
        message = try values.decodeIfPresent(String.self, forKey: .message)
        data = try values.decodeIfPresent([PostData].self, forKey: .data)
    }

}
struct PostData : Codable {
    let id : Int?
    let trending : String?
    let title : String?
    let subtitle : String?
    let collection_name : String?
    let description : String?
    let caption_image : String?
    let image1 : String?
    let image2 : String?
    let image3 : String?
    let image4 : String?
    let image5 : String?
    let user_id : String?
    let favrte_routine : String?

    enum CodingKeys: String, CodingKey {

        case id = "id"
        case trending = "trending"
        case title = "title"
        case subtitle = "subtitle"
        case collection_name = "collection_name"
        case description = "description"
        case caption_image = "caption_image"
        case image1 = "image1"
        case image2 = "image2"
        case image3 = "image3"
        case image4 = "image4"
        case image5 = "image5"
        case user_id = "user_id"
        case favrte_routine = "favrte_routine"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        id = try values.decodeIfPresent(Int.self, forKey: .id)
        trending = try values.decodeIfPresent(String.self, forKey: .trending)
        title = try values.decodeIfPresent(String.self, forKey: .title)
        subtitle = try values.decodeIfPresent(String.self, forKey: .subtitle)
        collection_name = try values.decodeIfPresent(String.self, forKey: .collection_name)
        description = try values.decodeIfPresent(String.self, forKey: .description)
        caption_image = try values.decodeIfPresent(String.self, forKey: .caption_image)
        image1 = try values.decodeIfPresent(String.self, forKey: .image1)
        image2 = try values.decodeIfPresent(String.self, forKey: .image2)
        image3 = try values.decodeIfPresent(String.self, forKey: .image3)
        image4 = try values.decodeIfPresent(String.self, forKey: .image4)
        image5 = try values.decodeIfPresent(String.self, forKey: .image5)
        user_id = try values.decodeIfPresent(String.self, forKey: .user_id)
        favrte_routine = try values.decodeIfPresent(String.self, forKey: .favrte_routine)
    }

}

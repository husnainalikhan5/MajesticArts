//
//  QuotationModel.swift
//  MajesticArt
//
//  Created by Uzma  Amjad on 23/10/2020.
//  Copyright © 2020 Apple. All rights reserved.
//

import Foundation
struct QuotationModel : Codable {
    let status : Int?
    let message : String?
    let data : QuotationData?

    enum CodingKeys: String, CodingKey {

        case status = "status"
        case message = "message"
        case data = "data"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        status = try values.decodeIfPresent(Int.self, forKey: .status)
        message = try values.decodeIfPresent(String.self, forKey: .message)
        data = try values.decodeIfPresent(QuotationData.self, forKey: .data)
    }

}

struct QuotationData : Codable {
    let f_name : String?
    let l_name : String?
    let email : String?
    let phone : String?
    let qoutation : String?
    let id : Int?

    enum CodingKeys: String, CodingKey {

        case f_name = "f_name"
        case l_name = "l_name"
        case email = "email"
        case phone = "phone"
        case qoutation = "qoutation"
        case id = "id"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        f_name = try values.decodeIfPresent(String.self, forKey: .f_name)
        l_name = try values.decodeIfPresent(String.self, forKey: .l_name)
        email = try values.decodeIfPresent(String.self, forKey: .email)
        phone = try values.decodeIfPresent(String.self, forKey: .phone)
        qoutation = try values.decodeIfPresent(String.self, forKey: .qoutation)
        id = try values.decodeIfPresent(Int.self, forKey: .id)
    }

}

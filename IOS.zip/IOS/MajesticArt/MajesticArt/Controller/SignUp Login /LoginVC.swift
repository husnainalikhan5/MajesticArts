//
//  LoginVC.swift
//  MajesticArt
//
//  Created by Uzma Amjad on 10/5/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit
import SVProgressHUD
import Toaster
import Kingfisher
import SwiftyJSON
import Alamofire
import LayoutHelper

class LoginVC: UIViewController {
    //MARK:- OUTLETS
    @IBOutlet var segmentControl: UISegmentedControl!
    @IBOutlet var viewContainer: UIView!
    @IBOutlet var signUpView: UIView!
    @IBOutlet var signInView: UIView!
    @IBOutlet var emailTF: UITextField!
    @IBOutlet var passswordTF: UITextField!
    @IBOutlet var firstNameTF: UITextField!
    @IBOutlet var lastNameTF: UITextField!
    @IBOutlet var phoneNumTF: UITextField!
    @IBOutlet var emailSignUpTF: UITextField!
    @IBOutlet var passwordSignUpTF: UITextField!
    @IBOutlet var logoView: UIView!
    @IBOutlet var loginStackView: UIStackView!
    @IBOutlet var logoViewTopConstraint: NSLayoutConstraint!
    @IBOutlet var centreAlignedConstraint: NSLayoutConstraint!
    
    
    //MARK:- VARIABLES
    var user : UserModel?
    
    //MARK:-ARRAYS
    override func viewDidLoad() {
        super.viewDidLoad()
        //    self.logoViewTopConstraint.constant = self.view.frame.height / 2
        
        self.logoView.alpha = 1.0
        self.loginStackView.alpha = 0.0
        self.segmentControl.alpha = 0.0
        //        setUpLogoFadeAnimation()
        moveLogoUp()
        segmentControl.setBackgroundImage(UIImage(named: "white background"), for: .normal, barMetrics: .default)
        let normalTextAttribute = [NSAttributedString.Key.font: UIFont(name: "Lato-Regular", size: 16)!  , NSAttributedString.Key.foregroundColor : UIColor(named: "Mustard Color")!]
        let selectedTextAttribute = [NSAttributedString.Key.font: UIFont(name: "Lato-Regular", size: 16)!  , NSAttributedString.Key.foregroundColor : UIColor(named: "Dark Royal Blue")!]
        
        segmentControl.setTitleTextAttributes(normalTextAttribute, for: .normal)
        segmentControl.setTitleTextAttributes(selectedTextAttribute, for: .selected )
        segmentControl.selectedSegmentIndex = 0
        
        signUpView.isHidden = true
        setUpUI()
    }
    
    //MARK:- ACTIONS
    @IBAction func signUpBtnPressed(_ sender: Any) {
        hitSignUpApi()
    }
    @IBAction func loginTapped(_ sender: UIButton) {
        hitLoginApi()
        
    }
    @IBAction func switchLoginSignUp(_ sender: UISegmentedControl) {
        
        switch sender.selectedSegmentIndex {
        case 0:
            signUpView.isHidden = true
            signInView.isHidden = false
            
            break
        case 1:
            signInView.isHidden = true
            signUpView.isHidden = false
            
            
            break
        default:
            break
        }
    }
    
    //MARK:- FUNCTIONS
    
    func setUpUI(){
        let bottomLine = CALayer()
        bottomLine.frame = CGRect(x: 0.0, y: emailTF.frame.height - 1, width: emailTF.frame.width, height: 1)
        bottomLine.backgroundColor = UIColor(named: "Dark Royal Blue")?.cgColor
        emailTF.borderStyle = UITextField.BorderStyle.none
        emailTF.layer.addSublayer(bottomLine)
        let bottomLine2 = CALayer()
        bottomLine2.frame = CGRect(x: 0.0, y: passswordTF.frame.height - 1, width: passswordTF.frame.width, height: 1)
        bottomLine2.backgroundColor = UIColor(named: "Dark Royal Blue")?.cgColor
        passswordTF.borderStyle = UITextField.BorderStyle.none
        passswordTF.layer.addSublayer(bottomLine2)
        
        let bottomLine3 = CALayer()
        bottomLine3.frame = CGRect(x: 0.0, y: firstNameTF.frame.height - 1, width: firstNameTF.frame.width, height: 1)
        bottomLine3.backgroundColor = UIColor(named: "Dark Royal Blue")?.cgColor
        firstNameTF.borderStyle = UITextField.BorderStyle.none
        firstNameTF.layer.addSublayer(bottomLine3)
        
        let bottomLine4 = CALayer()
        bottomLine4.frame = CGRect(x: 0.0, y: lastNameTF.frame.height - 1, width: lastNameTF.frame.width, height: 1)
        bottomLine4.backgroundColor = UIColor(named: "Dark Royal Blue")?.cgColor
        lastNameTF.borderStyle = UITextField.BorderStyle.none
        lastNameTF.layer.addSublayer(bottomLine4)
        
        let bottomLine5 = CALayer()
        bottomLine5.frame = CGRect(x: 0.0, y: phoneNumTF.frame.height - 1, width: phoneNumTF.frame.width, height: 1)
        bottomLine5.backgroundColor = UIColor(named: "Dark Royal Blue")?.cgColor
        phoneNumTF.borderStyle = UITextField.BorderStyle.none
        phoneNumTF.layer.addSublayer(bottomLine5)
        
        let bottomLine6 = CALayer()
        bottomLine6.frame = CGRect(x: 0.0, y: emailSignUpTF.frame.height - 1, width: emailSignUpTF.frame.width, height: 1)
        bottomLine6.backgroundColor = UIColor(named: "Dark Royal Blue")?.cgColor
        emailSignUpTF.borderStyle = UITextField.BorderStyle.none
        emailSignUpTF.layer.addSublayer(bottomLine6)
        
        let bottomLine7 = CALayer()
        bottomLine7.frame = CGRect(x: 0.0, y: passwordSignUpTF.frame.height - 1, width: passwordSignUpTF.frame.width, height: 1)
        bottomLine7.backgroundColor = UIColor(named: "Dark Royal Blue")?.cgColor
        passwordSignUpTF.borderStyle = UITextField.BorderStyle.none
        passwordSignUpTF.layer.addSublayer(bottomLine7)
        
    }
    func setUpLogoFadeAnimation()
    {
        if(self.logoView.alpha == 0.0)
        {
            UIView.animate(withDuration: 1.5, delay: 1, options: .curveEaseOut, animations: {
                self.logoView.alpha = 1.0
            })
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5 ) {
                self.moveLogoUp()
            }
            
        }
        else{
            UIView.animate(withDuration: 1.5, delay: 0.2, options: .curveEaseOut, animations: {
                self.logoView.alpha = 0.0
            })
            
        }
        
    }
    func moveLogoUp()  {
        UIView.animate(withDuration: 3 , animations: {
            if UIDevice().userInterfaceIdiom == .phone {
            switch UIScreen.main.nativeBounds.height {
                case 1136:
                    print("iPhone 5 or 5S or 5C")

                case 1334:
                    print("iPhone 6/6S/7/8")
                 self.logoView.frame.origin.y -= 245
                

                case 1920, 2208:
                    print("iPhone 6+/6S+/7+/8+")
                 self.logoView.frame.origin.y -= 260
                case 2436:
                    print("iPhone X/XS/11 Pro")
                 self.logoView.frame.origin.y -= 270
                case 2688:
                    print("iPhone XS Max/11 Pro Max")
                    self.centreAlignedConstraint.constant = -300
                  self.logoView.frame.origin.y -= 300
                case 1792:
                    print("iPhone XR/ 11 ")
                  self.logoView.frame.origin.y -= 260
                

                default:
                    print("Unknown")
                }
            
          
           
            }}) { (done) in
            UIView.animate(withDuration: 0.75, animations: {
                self.loginStackView.alpha = 1.0
                self.segmentControl.alpha = 1.0
            }) { (done) in
                print("done")
            }
        }
        //        self.logoViewTopConstraint.constant = 0
    }
    
    
    
    
    //MARK:- SIGN UP API RESPONSE
    func hitSignUpApi()
    {
        if emailSignUpTF.text!.count == 0 || passwordSignUpTF.text!.count == 0 || firstNameTF.text!.count == 0 || lastNameTF.text!.count == 0 || phoneNumTF.text!.count == 0 {
            SVProgressHUD.dismiss()
            Toast(text: "Please fill all fields.").show()
        }
        else
        {
            let param: Parameters = ["f_name" : firstNameTF.text! , "l_name" : lastNameTF.text! , "email" : emailSignUpTF.text! , "password" : passwordSignUpTF.text! , "phone" : phoneNumTF.text!]
            let url = "\(Apis.baseURL+Apis.signUp)"
            AF.request(url, method: .post, parameters: param, encoding: URLEncoding.default, headers: nil).validate(statusCode: 200..<300).responseData { response in
                SVProgressHUD.dismiss()
                switch response.result{
                case.success(let value):
                    let json = JSON(value)
                    print(json)
                    
                    let status = json["status"].intValue
                    
                    if status == 200
                    {
                        let result = try? JSON(data: response.data!)
                        print(result as Any)
                        Toast(text: "Signed Up Succesfully!").show()
                        self.signUpView.isHidden = true
                        self.signInView.isHidden = false
                    }
                    else
                    {
                        Toast(text: "User Already Exists!").show()
                    }
                case.failure:
                    print("Error Signing Up!")
                    break
                }
            }
        }
    }
    
    func hitLoginApi()
    {
        let jsonURLString = "\(Apis.baseURL+Apis.login)"
        guard let url = URL(string: jsonURLString) else { return }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        let parameterToSend = "email=" + emailTF.text! + "&password=" + passswordTF.text!
        request.httpBody = parameterToSend.data(using: String.Encoding.utf8)
        URLSession.shared.dataTask(with: request as URLRequest) { (data, response, error) in
            guard let data = data else { return }
            
            do {
                self.user = try JSONDecoder().decode(UserModel.self, from: data)
                print(self.user!)
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                    if(self.user?.status == 400)
                    {
                        SVProgressHUD.dismiss()
                        
                        print("invalid")
                        Toast(text: "Please enter valid Email or Password").show()
                    }
                    else{
                        SVProgressHUD.dismiss()
                        userDefaults.set(self.user?.data?.id, forKey: "userID")
                        userDefaults.set((self.user?.data?.f_name)! + " " + (self.user?.data?.l_name)!  , forKey: "userName")
                        userDefaults.set(self.user?.data?.f_name, forKey: "userFname")
                        userDefaults.set(self.user?.data?.l_name, forKey: "userLname")
                        userDefaults.set(self.user?.data?.email, forKey: "userEmail")
                        userDefaults.set(self.user?.data?.phone, forKey: "userPhone")
                        self.moveToDashboard()
                    }
                    
                }
            } catch let jsonError{
                print(jsonError.localizedDescription)
            }
        }.resume()
    }
    
}

extension LoginVC{
    
    func moveToDashboard(){
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let navigationController = storyboard.instantiateViewController(withIdentifier: "NavigationController") as! UINavigationController
        navigationController.setViewControllers([storyboard.instantiateViewController(withIdentifier: "HomeVC")], animated: false)
        
        let mainViewController = storyboard.instantiateViewController(withIdentifier: "mai") as! MainViewController
        mainViewController.rootViewController = navigationController
        mainViewController.setup(type: UInt(0))
        
        let window = UIApplication.shared.delegate!.window!!
        window.rootViewController = mainViewController
        
        UIView.transition(with: window, duration: 0.3, options: [.transitionCrossDissolve], animations: nil, completion: nil)
    }
}

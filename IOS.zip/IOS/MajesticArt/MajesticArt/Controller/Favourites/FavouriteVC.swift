//
//  FavouriteVC.swift
//  MajesticArts
//
//  Created by Uzma  Amjad on 30/09/2020.
//  Copyright © 2020 Uzma  Amjad. All rights reserved.
//

import UIKit
import SVProgressHUD
import Kingfisher

class FavouriteVC: UIViewController {
    
    
    //MARK:- OUTLETS
    
    
    @IBOutlet var collectionView: UICollectionView!
    
    //MARK:- VARIABLES
    var favPosts : PostModel?
    //MARK:- ARRAYS
    var itemImagesArr : [UIImage] = [UIImage(named: "sample image 1")! , UIImage(named: "sample image 2")! , UIImage(named: "sample image 3")! , UIImage(named: "sample image 4")! ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        SVProgressHUD.show()
        hitGetFavourites()
        
    }
    
    //MARK:- ACTIONS
    //MARK:- FUNCTIONS
    func hitGetFavourites()
    {
        let jsonURLString = "\(Apis.baseURL+Apis.get_favroute)"
        guard let url = URL(string: jsonURLString) else { return }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        let parameterToSend = "user_id=" + "\(userDefaults.integer(forKey: "userID"))"
        request.httpBody = parameterToSend.data(using: String.Encoding.utf8)
        URLSession.shared.dataTask(with: request as URLRequest) { (data, response, error) in
            guard let data = data else { return }
            
            do {
                self.favPosts = try JSONDecoder().decode(PostModel.self, from: data)
                print(self.favPosts ?? "")
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                    self.collectionView.reloadData()
                    SVProgressHUD.dismiss()
                }
                
            } catch let jsonError{
                print(jsonError.localizedDescription)
            }
        }.resume()
    }
}
//MARK:- EXTENSIONS


extension FavouriteVC : UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.width/2, height: collectionView.frame.width/2 + 50 )
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return favPosts?.data?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SearchCVCell", for: indexPath) as? SearchCVCell
        //
        
        cell?.itemImg.kf.setImage(with: URL(string: (favPosts?.data?[indexPath.row].caption_image)!))
        cell?.itemTitle.text = favPosts?.data?[indexPath.row].title
        cell?.itemSubTitle.text = favPosts?.data?[indexPath.row].subtitle
        
        return cell!
        
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if #available(iOS 13.0, *) {
            let vc = storyboard?.instantiateViewController(identifier: "SingleItemDetailVC") as! SingleItemDetailVC
            vc.selectedIndex = indexPath.row
            vc.selectedPost = favPosts
            
            self.navigationController?.pushViewController(vc, animated: true)
        } else {
            // Fallback on earlier versions
        }
        
    }
    
    
}

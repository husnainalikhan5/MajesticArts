//
//  NavigationController.swift
//  MajesticArt
//
//  Created by apple on 10/5/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit
import LGSideMenuController

@available(iOS 13.0, *)
class NavigationController: UINavigationController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setFont()
    }
    override var shouldAutorotate : Bool {
        
        return true
    }
    override var preferredStatusBarStyle : UIStatusBarStyle {
        return .default
    }
    
    func setFont()
    {
        // set font for title
        self.navigationBar.largeTitleTextAttributes = [NSAttributedString.Key.font: UIFont(name: "philosopher-bold", size: 34)!  , NSAttributedString.Key.foregroundColor : UIColor(named: "Dark Royal Blue")!]
        self.navigationBar.titleTextAttributes = [NSAttributedString.Key.font: UIFont(name: "philosopher-bold", size: 24)! , NSAttributedString.Key.foregroundColor : UIColor(named: "Dark Royal Blue")!]
        // set font for navigation bar buttons
        //       UIBarButtonItem.appearance().setTitleTextAttributes([NSAttributedString.Key.font: UIFont(name: "philosopher-bold", size: 15)!], for: UIControl.State.normal)
        
        let yourBackImage = UIImage(systemName: "arrow.left")
        self.navigationController?.navigationBar.backIndicatorImage = yourBackImage
      
        self.navigationController?.navigationBar.backIndicatorTransitionMaskImage = yourBackImage
        let backButton = UIBarButtonItem()
        backButton.title = " "
        self.navigationController?.navigationBar.topItem?.backBarButtonItem = backButton
     
        
    }
}

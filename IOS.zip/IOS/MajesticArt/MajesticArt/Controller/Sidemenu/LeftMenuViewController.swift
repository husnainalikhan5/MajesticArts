//
//  LeftMenuViewController.swift
//  MajesticArt
//
//  Created by apple on 10/5/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit

struct structData {
    let dataImage:UIImage?
    let dataName:String?
}
class LeftMenuViewController: UIViewController {
    
    
    //MARK:- Variables
    
    //MARK:- Arrays
    //    let arrayData = [structData(dataImage: #imageLiteral(resourceName: "home-4-line (2)"), dataName: "Home"),
    //    structData(dataImage: #imageLiteral(resourceName: "shopping-bag-2-line (1)"), dataName: "My Orders"),
    //    structData(dataImage: #imageLiteral(resourceName: "Path 83"), dataName: "Menu"),
    //    structData(dataImage: #imageLiteral(resourceName: "Path 81"), dataName: "Ratings"),
    //    structData(dataImage: #imageLiteral(resourceName: "money-dollar-circle-line (2)"), dataName: "Tips"),
    //    structData(dataImage: #imageLiteral(resourceName: "heart-line (3)"), dataName: "Help"),
    //    structData(dataImage: #imageLiteral(resourceName: "settings-3-line (2)"), dataName: "Settings")]
    
    var optionsArr = ["Home", "About Majestic Arts", "Our Collection", "Settings"]
    //MARK:- outlets
    @IBOutlet weak var tblVu: UITableView!
    @IBOutlet var nameLbl: UILabel!
    @IBOutlet var emailLbl: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        nameLbl.text = userDefaults.string(forKey: "userName")
        emailLbl.text = userDefaults.string(forKey: "userEmail")
        
    }
    
    override var prefersStatusBarHidden: Bool {
        return true
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .default
    }
    
    override var preferredStatusBarUpdateAnimation: UIStatusBarAnimation {
        return .fade
    }
    
    @IBAction func logoutPressed(_ sender: Any) {
        let domain = Bundle.main.bundleIdentifier!
        UserDefaults.standard.removePersistentDomain(forName: domain)
        UserDefaults.standard.synchronize()
        print(Array(UserDefaults.standard.dictionaryRepresentation().keys).count)
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let navigationController = storyboard.instantiateViewController(withIdentifier: "NavigationController") as! UINavigationController
        navigationController.setViewControllers([storyboard.instantiateViewController(withIdentifier: "LoginVC")], animated: false)
        
        let mainViewController = storyboard.instantiateViewController(withIdentifier: "mai") as! MainViewController
        mainViewController.rootViewController = navigationController
        mainViewController.setup(type: UInt(0))
        
        let window = UIApplication.shared.delegate!.window!!
        window.rootViewController = mainViewController
        
        UIView.transition(with: window, duration: 0.3, options: [.transitionCrossDissolve], animations: nil, completion: nil)
        
    }
    
    
}

extension LeftMenuViewController : UITableViewDelegate , UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return optionsArr.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 55
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! LeftViewCell
        cell.titleLabel.text = optionsArr[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch indexPath.row{
        case 0:
            moveToHome()
            break
        case 1:
            moveToAboutScreen()
            break
        case 2:
            moveToOurCollection()
            
            break
        case 3:
            moveToSettings()
            break
        default:
            return
        }
    }
}

extension LeftMenuViewController{
    func moveToMyOrder(){
        //        let MyOrderVC = self.storyboard?.instantiateViewController(withIdentifier: "MyOrderVC") as! MyOrderVC
        //
        //        self.present(MyOrderVC, animated: false, completion: nil)
    }
    func moveMenu(){
        //        let MenuVC = self.storyboard?.instantiateViewController(withIdentifier: "MenuNavigationVC") as! MenuNavigationVC
        //
        //        self.present(MenuVC, animated: false, completion: nil)
    }
    func moveToRating(){
        //       let RatingVC = self.storyboard?.instantiateViewController(withIdentifier: "RatingVC") as! RatingVC
        //
        //        self.present(RatingVC, animated: false, completion: nil)
    }
    func moveToTips(){
        //      let TipsHistoryVC = self.storyboard?.instantiateViewController(withIdentifier: "TipsHistoryVC") as! TipsHistoryVC
        //
        // self.present(TipsHistoryVC, animated: false, completion: nil)
    }
    func moveToHelp(){
        //        let SettingVC = self.storyboard?.instantiateViewController(withIdentifier: "SettingVC") as! SettingVC
        //
        //        self.present(SettingVC, animated: false, completion: nil)
    }
    
    
    
}
extension UIViewController{
    func moveToHome(){
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let navigationController = storyboard.instantiateViewController(withIdentifier: "NavigationController") as! UINavigationController
        navigationController.setViewControllers([storyboard.instantiateViewController(withIdentifier: "HomeVC")], animated: false)
        
        let mainViewController = storyboard.instantiateViewController(withIdentifier: "mai") as! MainViewController
        mainViewController.rootViewController = navigationController
        mainViewController.setup(type: UInt(0))
        
        let window = UIApplication.shared.delegate!.window!!
        window.rootViewController = mainViewController
        
        UIView.transition(with: window, duration: 0.3, options: [.transitionCrossDissolve], animations: nil, completion: nil)
        
    }
    
    func moveToAboutScreen(){
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let navigationController = storyboard.instantiateViewController(withIdentifier: "NavigationController") as! UINavigationController
        navigationController.setViewControllers([storyboard.instantiateViewController(withIdentifier: "AboutVC")], animated: false)
        
        let mainViewController = storyboard.instantiateViewController(withIdentifier: "mai") as! MainViewController
        mainViewController.rootViewController = navigationController
        mainViewController.setup(type: UInt(0))
        
        let window = UIApplication.shared.delegate!.window!!
        window.rootViewController = mainViewController
        
        UIView.transition(with: window, duration: 0.3, options: [.transitionCrossDissolve], animations: nil, completion: nil)
        
    }
    
    func moveToOurCollection(){
        
        
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let navigationController = storyboard.instantiateViewController(withIdentifier: "NavigationController") as! UINavigationController
        navigationController.setViewControllers([storyboard.instantiateViewController(withIdentifier: "OurCollectionVC")], animated: false)
        
        let mainViewController = storyboard.instantiateViewController(withIdentifier: "mai") as! MainViewController
        mainViewController.rootViewController = navigationController
        mainViewController.setup(type: UInt(0))
        
        let window = UIApplication.shared.delegate!.window!!
        window.rootViewController = mainViewController
        navigationController.navigationBar.prefersLargeTitles = true
        //         let leftButton = UIButton()
        //       //           rightButton.setTitle("Right Button", for: .normal)
        //        if #available(iOS 13.0, *) {
        //            leftButton.setImage(UIImage(systemName: "arrow.left"), for: .normal)
        //            navigationController.navigationBar.addSubview(leftButton)
        //                            leftButton.tag = 1
        //                            leftButton.frame = CGRect(x: 0 , y: 0, width: 45, height: 45)
        //            leftButton.setPreferredSymbolConfiguration(.init(scale: .large), forImageIn: .normal)
        //            leftButton.tintColor = UIColor(named: "Dark Royal Blue")
        //        } else {
        //            // Fallback on earlier versions
        //        }
        //       //           rightButton.setTitleColor(.purple, for: .normal)
        //       //           rightButton.addTarget(self, action: #selector(rightButtonTapped(_:)), for: .touchUpInside)
        //
        
        
        UIView.transition(with: window, duration: 0.3, options: [.transitionCrossDissolve], animations: nil, completion: nil)
        
    }
    
    func moveToSettings(){
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let navigationController = storyboard.instantiateViewController(withIdentifier: "NavigationController") as! UINavigationController
        navigationController.setViewControllers([storyboard.instantiateViewController(withIdentifier: "SettingsVC")], animated: false)
        
        let mainViewController = storyboard.instantiateViewController(withIdentifier: "mai") as! MainViewController
        mainViewController.rootViewController = navigationController
        mainViewController.setup(type: UInt(0))
        
        let window = UIApplication.shared.delegate!.window!!
        window.rootViewController = mainViewController
        
        UIView.transition(with: window, duration: 0.3, options: [.transitionCrossDissolve], animations: nil, completion: nil)
        
    }
}

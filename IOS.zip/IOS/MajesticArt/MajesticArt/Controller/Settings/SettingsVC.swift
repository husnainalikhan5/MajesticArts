//
//  SettingsVC.swift
//  MajesticArts
//
//  Created by Uzma  Amjad on 30/09/2020.
//  Copyright © 2020 Uzma  Amjad. All rights reserved.
//

import UIKit
import SVProgressHUD
import Toaster

@available(iOS 13.0, *)
class SettingsVC: UIViewController {
    
    //MARK:- OUTLETS
    @IBOutlet var newPasswordTF: UITextField!
    @IBOutlet var retypeTF: UITextField!
    @IBOutlet var mobileNumTF: UITextField!
    //MARK:- VARIABLES
    //MARK:- ARRAYS
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        self.navigationController?.setNavigationBarHidden(false, animated: false)
        
        
    }
    override func viewWillAppear(_ animated: Bool) {
        setupUI()
        self.navigationController?.setNavigationBarHidden(false, animated: false)
        
    }
    override func viewWillDisappear(_ animated: Bool) {
        self.navigationItem.title = " "
    }
    //MARK:- ACTIONS
    @IBAction func phoneNumSubmitPressed(_ sender: Any) {
        SVProgressHUD.show()
        hitUpdatePhoneAPI()
    }
    @IBAction func passwordSubmitPressed(_ sender: Any) {
        SVProgressHUD.show()
        hitUpdatePasswordAPI()
    }
    
    
    //MARK:- FUNCTIONS
    func setupUI(){
        
        //Navigation Item SETUP
        self.navigationController?.navigationBar.prefersLargeTitles = true
        self.navigationItem.largeTitleDisplayMode = .always
        self.navigationItem.title = "Settings"
        self.navigationController?.navigationBar.backIndicatorImage = UIImage(systemName: "arrow.left")
        self.navigationController?.navigationBar.backIndicatorTransitionMaskImage = UIImage(systemName: "arrow.left")
        self.navigationController?.navigationBar.largeTitleTextAttributes = [NSAttributedString.Key.font: UIFont(name: "philosopher-bold", size: 34)!  , NSAttributedString.Key.foregroundColor : UIColor(named: "Dark Royal Blue")!]
        let backButton = UIBarButtonItem()
        backButton.title = ""
        let leftButton = UIButton()
        leftButton.setImage(UIImage(systemName: "arrow.left"), for: .normal)
        navigationController?.navigationBar.addSubview(leftButton)
        leftButton.tag = 1
        leftButton.frame = CGRect(x: 0 , y: 0, width: 45, height: 45)
        leftButton.setPreferredSymbolConfiguration(.init(scale: .large), forImageIn: .normal)
        leftButton.tintColor = UIColor(named: "Dark Royal Blue")
        self.navigationController?.navigationBar.topItem?.backBarButtonItem = backButton
        self.navigationController?.navigationBar.topItem?.backBarButtonItem?.tintColor = UIColor(red: 91/255, green: 93/255, blue: 105/255, alpha: 1)
        leftButton.addTarget(self, action: #selector(backButtonPressed), for: .touchUpInside )
        
        
        
        //Text field bottom line
        let bottomLine = CALayer()
        bottomLine.frame = CGRect(x: 0.0, y: newPasswordTF.frame.height - 1, width: newPasswordTF.frame.width, height: 1)
        bottomLine.backgroundColor = UIColor(named: "Dark Royal Blue")?.cgColor
        newPasswordTF.borderStyle = UITextField.BorderStyle.none
        newPasswordTF.layer.addSublayer(bottomLine)
        
        let bottomLine2 = CALayer()
        
        bottomLine2.frame = CGRect(x: 0.0, y: retypeTF.frame.height - 1, width: retypeTF.frame.width, height: 1)
        bottomLine2.backgroundColor = UIColor(named: "Dark Royal Blue")?.cgColor
        retypeTF.borderStyle = UITextField.BorderStyle.none
        retypeTF.layer.addSublayer(bottomLine2)
        
        let bottomLine3 = CALayer()
        
        bottomLine3.frame = CGRect(x: 0.0, y: retypeTF.frame.height - 1, width: retypeTF.frame.width, height: 1)
        bottomLine3.backgroundColor = UIColor(named: "Dark Royal Blue")?.cgColor
        mobileNumTF.borderStyle = UITextField.BorderStyle.none
        mobileNumTF.layer.addSublayer(bottomLine3)
        
    }
    @objc func backButtonPressed()
    {
        print("back pressed")
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let navigationController = storyboard.instantiateViewController(withIdentifier: "NavigationController") as! UINavigationController
        navigationController.setViewControllers([storyboard.instantiateViewController(withIdentifier: "HomeVC")], animated: false)
        
        let mainViewController = storyboard.instantiateViewController(withIdentifier: "mai") as! MainViewController
        mainViewController.rootViewController = navigationController
        mainViewController.setup(type: UInt(0))
        
        let window = UIApplication.shared.delegate!.window!!
        window.rootViewController = mainViewController
        
        UIView.transition(with: window, duration: 0.3, options: [.transitionCrossDissolve], animations: nil, completion: nil)
    }
    
    func hitUpdatePhoneAPI()
    {
        let jsonURLString = "\(Apis.baseURL+Apis.update_phone)"
        guard let url = URL(string: jsonURLString) else { return }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        let parameterToSend = "user_id=" + "\(userDefaults.integer(forKey: "userID"))" + "&phone=" + mobileNumTF.text!
        request.httpBody = parameterToSend.data(using: String.Encoding.utf8)
        URLSession.shared.dataTask(with: request as URLRequest) { (data, response, error) in
            guard let data = data else { return }
            SVProgressHUD.dismiss()
            do {
                Toast(text: "Phone Number Changed Successfully!").show()
                
            }
            catch let jsonError{
                print(jsonError.localizedDescription)
                Toast(text: "Error Changing Phone Number!").show()
            }
        }.resume()
    }
    
    func hitUpdatePasswordAPI()
    {
        let jsonURLString = "http://majestic-arts.com/majistic/public/api/reset_password"
        guard let url = URL(string: jsonURLString) else { return }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        let parameterToSend = "user_id=" + "\(userDefaults.integer(forKey: "userID"))" + "&password=" + newPasswordTF.text! + "&conf_password=" + retypeTF.text!
        request.httpBody = parameterToSend.data(using: String.Encoding.utf8)
        URLSession.shared.dataTask(with: request as URLRequest) { (data, response, error) in
            guard let data = data else { return }
            SVProgressHUD.dismiss()
            do {
                Toast(text: "Password Changed Successfully!").show()
                
            } catch let jsonError{
                print(jsonError.localizedDescription)
                Toast(text: "Error Changing Password!").show()
            }
        }.resume()
    }
 
}
//MARK:- EXTENSIONS


//
//  forYouCollectionsTVC.swift
//  MajesticArts
//
//  Created by Uzma  Amjad on 01/10/2020.
//  Copyright © 2020 Uzma  Amjad. All rights reserved.
//

import UIKit

class forYouCollectionsTVC: UITableViewCell {
    
    @IBOutlet var collectionImg: UIImageView!
    @IBOutlet var collectionTitle: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    
    
}

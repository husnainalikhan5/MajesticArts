//
//  ForYouVC.swift
//  MajesticArts
//
//  Created by Uzma  Amjad on 30/09/2020.
//  Copyright © 2020 Uzma  Amjad. All rights reserved.
//

import UIKit
import SVProgressHUD
import Kingfisher

class ForYouVC: UIViewController {
    
    //MARK:- OUTLETS
    @IBOutlet var tableView: UITableView!
    @IBOutlet var trendingCollectionView: UICollectionView!
    @IBOutlet var headerCustomView: UIView!
    
    
    //MARK:- VARIABLES
    var trendingCollection : CollectionModel?
    var trendingPosts : PostModel?
    //MARK:- ARRAYS
    
    var trendingImagesArr : [UIImage] = [UIImage(named: "sample image 1")! , UIImage(named: "sample image 2")! , UIImage(named: "sample image 3")! , UIImage(named: "sample image 4")! ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.tableHeaderView = headerCustomView
        SVProgressHUD.show()
        hitGetTrendingCollectionsApi()
        hitGetTrendingPostsAPI()
        
    }
    
    //MARK:- ACTIONS
    //MARK:- FUNCTIONS
    
    //MARK:- Trending Posts Api
    func hitGetTrendingPostsAPI()
    {
        let jsonURLString = "\(Apis.baseURL+Apis.trending_posts)"
        guard let url = URL(string: jsonURLString) else { return }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        let parameterToSend = "user_id=" + "\(userDefaults.integer(forKey: "userID"))"
        request.httpBody = parameterToSend.data(using: String.Encoding.utf8)
        URLSession.shared.dataTask(with: request as URLRequest) { (data, response, error) in
            guard let data = data else { return }
            SVProgressHUD.dismiss()
            do {
                self.trendingPosts = try JSONDecoder().decode(PostModel.self, from: data)
                print(self.trendingPosts ?? "")
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                    self.trendingCollectionView.reloadData()
                }
                
            } catch let jsonError{
                print(jsonError.localizedDescription)
            }
        }.resume()
    }
    //MARK:- Trending Collection Api
    func hitGetTrendingCollectionsApi()
    {
        let jsonURLString = "\(Apis.baseURL+Apis.tranding_collections)"
        guard let url = URL(string: jsonURLString) else { return }
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        //        let parameterToSend = "user_id=" + "\(UserDefaults.standard.integer(forKey: "userID"))"
        //                request.httpBody = parameterToSend.data(using: String.Encoding.utf8)
        
        URLSession.shared.dataTask(with: request as URLRequest) { (data, response, error) in
            guard let data = data else { return }
            
            do {
                self.trendingCollection = try JSONDecoder().decode(CollectionModel.self, from: data)
                print(self.trendingCollection ?? "")
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                    self.tableView.reloadData()
                    SVProgressHUD.dismiss()
                }
            } catch {
                SVProgressHUD.dismiss()
                let alert = UIAlertController(title: "Error", message: "Error Recieving Data!", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "Okay", style: UIAlertAction.Style.cancel , handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
        }.resume()
    }
}
//MARK:- EXTENSIONS


extension ForYouVC: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 250, height: 300)
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return trendingPosts?.data?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "TrendingCVCell", for: indexPath) as? TrendingCVCell
        //
        cell?.titleLbl.text = trendingPosts?.data?[indexPath.row].title
        cell?.subTitleLbl.text = trendingPosts?.data?[indexPath.row].subtitle
        cell?.paintingImg.kf.setImage(with: URL(string: (trendingPosts?.data?[indexPath.row].caption_image)!))
        return cell!
        
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if #available(iOS 13.0, *) {
            let vc = storyboard?.instantiateViewController(identifier: "SingleItemDetailVC") as! SingleItemDetailVC
            vc.selectedIndex = indexPath.row
            vc.selectedPost = trendingPosts
            self.navigationController?.pushViewController(vc, animated: true)
        } else {
            // Fallback on earlier versions
        }
        
    }
    
    
}

extension ForYouVC  : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return trendingCollection?.data?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "forYouCollectionsTVC", for: indexPath) as! forYouCollectionsTVC
        cell.collectionImg.kf.setImage(with: URL(string: trendingCollection?.data?[indexPath.row].image ?? "" ))
        cell.collectionTitle.text = trendingCollection?.data?[indexPath.row].name
        cell.selectionStyle = .none
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 300
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if #available(iOS 13.0, *) {
            let vc = storyboard!.instantiateViewController(identifier: "SingleCollectionVC") as! SingleCollectionVC
            vc.selectedCollection = trendingCollection?.data?[indexPath.row].name
            self.navigationController?.pushViewController(vc, animated: true)
        } else {
            // Fallback on earlier versions
        }
        
    }
}

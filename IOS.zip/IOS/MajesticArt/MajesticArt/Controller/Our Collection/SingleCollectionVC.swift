//
//  SingleCollectionVC.swift
//  MajesticArts
//
//  Created by Uzma  Amjad on 30/09/2020.
//  Copyright © 2020 Uzma  Amjad. All rights reserved.
//

import UIKit
import SVProgressHUD
import Kingfisher

@available(iOS 13.0, *)
class SingleCollectionVC: UIViewController {
    
    //MARK:- OUTLETS
    @IBOutlet var collectionView: UICollectionView!
    //MARK:- VARIABLES
    
    var selectedCollection : String?
    var posts : PostModel?
    let leftButton = UIButton()
    
    //MARK:- ARRAYS
    var itemImagesArr : [UIImage] = [UIImage(named: "sample image 1")! , UIImage(named: "sample image 2")! , UIImage(named: "sample image 3")! , UIImage(named: "sample image 4")! , UIImage(named: "sample image 1")! , UIImage(named: "sample image 2")! , UIImage(named: "sample image 3")! , UIImage(named: "sample image 4")!]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpUI()
        self.navigationController?.setNavigationBarHidden(false, animated: false)
      self.navigationItem.leftBarButtonItem = nil
         self.navigationItem.hidesBackButton = true
             
        hitGetPostsByCollectionAPI()
        
        
        
    }
    override func viewWillAppear(_ animated: Bool) {
        setUpUI()
        self.navigationController?.setNavigationBarHidden(false, animated: false)
        removeRightButton()
    }
   
    
    //MARK:- ACTIONS
    //MARK:- FUNCTIONS
    func setUpUI()
    {
        
    
                  leftButton.setImage(UIImage(systemName: "arrow.left"), for: .normal)
                  leftButton.tintColor = UIColor(named: "Dark Royal Blue")
                  
              
              leftButton.setPreferredSymbolConfiguration(.init(scale: .large) , forImageIn: .normal)
        leftButton.setPreferredSymbolConfiguration( .init(weight: .regular), forImageIn: .normal)
        leftButton.setPreferredSymbolConfiguration(.init( scale: .large) , forImageIn: .normal)
              //           rightButton.setTitleColor(.purple, for: .normal)
              //           rightButton.addTarget(self, action: #selector(rightButtonTapped(_:)), for: .touchUpInside)
              navigationController?.navigationBar.addSubview(leftButton)
              leftButton.tag = 2
              leftButton.frame = CGRect(x: 0, y: 14, width: 160, height: 30)
              
              let targetView = self.navigationController?.navigationBar
              
              let trailingContraint = NSLayoutConstraint(item: leftButton, attribute:
                  .leadingMargin, relatedBy: .equal, toItem: targetView,
                                   attribute: .leadingMargin, multiplier: 1.0, constant: 16)
              let bottomConstraint = NSLayoutConstraint(item: leftButton, attribute: .top, relatedBy: .equal,
                                                        toItem: targetView, attribute: .top, multiplier: 1.0, constant: 10)
              leftButton.translatesAutoresizingMaskIntoConstraints = false
              NSLayoutConstraint.activate([trailingContraint, bottomConstraint])
        
              self.navigationController?.navigationBar.prefersLargeTitles = true

              self.navigationItem.largeTitleDisplayMode = .always
             self.navigationItem.title = "\(selectedCollection!)"
                   leftButton.addTarget(self, action: #selector(backButtonPressed), for: .touchUpInside )
//
         //
//                     let leftButton = UIButton()
//                          leftButton.setImage(UIImage(systemName: "arrow.left"), for: .normal)
//                          navigationController?.navigationBar.addSubview(leftButton)
//                          leftButton.tag = 1
//                          leftButton.frame = CGRect(x: 0 , y: 0, width: 45, height: 45)
//                          leftButton.setPreferredSymbolConfiguration(.init(scale: .large), forImageIn: .normal)
//                          leftButton.tintColor = UIColor(red: 91/255, green: 93/255, blue: 105/255, alpha: 1)
        //                  self.navigationController?.navigationBar.topItem?.backBarButtonItem = backButton
        //                  self.navigationController?.navigationBar.topItem?.backBarButtonItem?.tintColor = UIColor(red: 91/255, green: 93/255, blue: 105/255, alpha: 1)
//                          leftButton.addTarget(self, action: #selector(backButtonPressed), for: .touchUpInside )
//        self.navigationController?.navigationBar.prefersLargeTitles = true
//
//        self.navigationItem.largeTitleDisplayMode = .always
//        self.navigationItem.title = "\(selectedCollection!)"
//
////        self.navigationController?.navigationBar.backIndicatorImage = UIImage(systemName: "arrow.left")
////        self.navigationController?.navigationBar.backIndicatorTransitionMaskImage = UIImage(systemName: "arrow.left")
//
//        self.navigationController?.navigationBar.largeTitleTextAttributes = [NSAttributedString.Key.font: UIFont(name: "philosopher-bold", size: 34)!  , NSAttributedString.Key.foregroundColor : UIColor(named: "Dark Royal Blue")!]
////        let backButton = UIBarButtonItem()
////        backButton.title = " "
//
//        let leftButton = UIButton()
//        leftButton.setImage(UIImage(systemName: "arrow.left"), for: .normal)
//        navigationController?.navigationBar.addSubview(leftButton)
//        leftButton.tag = 1
//        leftButton.frame = CGRect(x: 0 , y: 0, width: 45, height: 45)
//        leftButton.setPreferredSymbolConfiguration(.init(scale: .large), forImageIn: .normal)
//        leftButton.tintColor = UIColor(named: "Dark Royal Blue")
////        self.navigationController?.navigationBar.topItem?.backBarButtonItem = backButton
//        self.navigationController?.navigationBar.topItem?.backBarButtonItem?.tintColor = UIColor(red: 91/255, green: 93/255, blue: 105/255, alpha: 1)
   
        
    }
    
    @objc func backButtonPressed()  {
        self.navigationController?.popViewController(animated: true)
    }
    func removeRightButton(){
        guard let subviews = self.navigationController?.navigationBar.subviews else{return}
        for view in subviews{
            if view.tag == 1{
                view.removeFromSuperview()
            }
            
        }
    }
    //MARK:- Get Posts API
    func hitGetPostsByCollectionAPI()
    {
        let jsonURLString = "http://majestic-arts.com/majistic/public/api/post_by_collections"
        guard let url = URL(string: jsonURLString) else { return }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        let parameterToSend = "user_id=" + "\(userDefaults.integer(forKey: "userID"))" + "&collection_name=" + selectedCollection!
        request.httpBody = parameterToSend.data(using: String.Encoding.utf8)
        URLSession.shared.dataTask(with: request as URLRequest) { (data, response, error) in
            guard let data = data else { return }
            SVProgressHUD.dismiss()
            do {
                self.posts = try JSONDecoder().decode(PostModel.self, from: data)
                print(self.posts ?? "")
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                    self.collectionView.reloadData()
                }
                
            } catch let jsonError{
                print(jsonError.localizedDescription)
            }
        }.resume()
    }
}
//MARK:- EXTENSIONS

@available(iOS 13.0, *)
extension SingleCollectionVC : UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.width/2, height: collectionView.frame.width/2 + 50 )
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return posts?.data?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SearchCVCell", for: indexPath) as? SearchCVCell
        //
        
        cell?.itemImg.kf.setImage(with: URL(string: posts?.data?[indexPath.row].caption_image ?? "" ))
        cell?.itemTitle.text = posts?.data?[indexPath.row].title
        cell?.itemSubTitle.text = posts?.data?[indexPath.row].subtitle
        
        return cell!
        
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if #available(iOS 13.0, *) {
            let vc = storyboard?.instantiateViewController(identifier: "SingleItemDetailVC") as! SingleItemDetailVC
            vc.selectedPost = posts
            vc.selectedIndex = indexPath.row
            let backButton = UIBarButtonItem()
            backButton.title = " "
            let leftButton = UIButton()
            leftButton.setImage(UIImage(systemName: "arrow.left"), for: .normal)
            vc.navigationController?.navigationBar.addSubview(leftButton)
            leftButton.tag = 1
            leftButton.frame = CGRect(x: 0 , y: 0, width: 45, height: 45)
            leftButton.setPreferredSymbolConfiguration(.init(scale: .large), forImageIn: .normal)
            leftButton.tintColor = UIColor(named: "Dark Royal Blue")
            vc.navigationController?.navigationBar.topItem?.backBarButtonItem = backButton
            vc.navigationController?.navigationBar.topItem?.backBarButtonItem?.tintColor = UIColor(red: 91/255, green: 93/255, blue: 105/255, alpha: 1)
            leftButton.addTarget(self, action: #selector(backButtonPressed), for: .touchUpInside )
            self.navigationController?.pushViewController(vc, animated: true)
        } else {
            // Fallback on earlier versions
        }
        
    }
    
    
}

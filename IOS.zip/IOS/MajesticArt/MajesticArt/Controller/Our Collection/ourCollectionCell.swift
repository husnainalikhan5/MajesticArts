//
//  ourCollectionCell.swift
//  MajesticArts
//
//  Created by Uzma  Amjad on 02/10/2020.
//  Copyright © 2020 Uzma  Amjad. All rights reserved.
//

import UIKit

class ourCollectionCell: UITableViewCell {
    
    //MARK:- OUTLETS
    @IBOutlet var foregroundView: UIView!
    @IBOutlet var collectionImg: UIImageView!
    @IBOutlet var collectionNameLbl: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }
    
}

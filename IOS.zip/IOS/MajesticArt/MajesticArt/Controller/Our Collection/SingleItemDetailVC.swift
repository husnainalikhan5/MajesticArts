//
//  SingleItemDetailVC.swift
//  MajesticArts
//
//  Created by Uzma  Amjad on 30/09/2020.
//  Copyright © 2020 Uzma  Amjad. All rights reserved.
//

import UIKit
import SVProgressHUD
import Alamofire
import SwiftyJSON
import  Toaster

@available(iOS 13.0, *)
class SingleItemDetailVC: UIViewController {
    
    //MARK:- OUTLETS
    @IBOutlet var tableView: UITableView!
    @IBOutlet var headerViewTV: UIView!
    @IBOutlet weak var SlideShowViewer: UIImageView!
    
    @IBOutlet weak var collectionView: BJAutoScrollingCollectionView! //Step 1
      @IBOutlet weak var collectionViewFlowLayout: UICollectionViewFlowLayout!
    
    //MARK:- VARIABLES
    var indexx = 0
    let animationDuration: TimeInterval = 0.25
    var switchingInterval: TimeInterval = 3
    var transition = CATransition()
    var selectedPost: PostModel?
    var selectedIndex : Int?
    var rightButton = UIButton()
    var leftButton = UIButton()
    var isFavourite = "yes"
    //MARK:- ARRAYS
    var imagesArr = [String]()
    var sliderImages : SliderImages?
     var quotation : QuotationModel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpUI()
        self.navigationController?.setNavigationBarHidden(false, animated: false)
        self.navigationItem.leftBarButtonItem = nil
        self.navigationItem.hidesBackButton = true
        self.tableView.tableHeaderView = headerViewTV
        self.collectionView.delegate = self
        self.collectionView.dataSource = self
        //        SVProgressHUD.show()
        //        animateImageView()
        hitGetSliderImagesAPI()
    }
    override func viewWillAppear(_ animated: Bool) {
        setUpUI()
        self.navigationController?.setNavigationBarHidden(false, animated: false)
        removeRightButton()
    }
    
    
    //MARK:- ACTIONS
    @IBAction func getQuotationBtnPressed(_ sender: Any) {
        hitGetQuotation()
    }
    
    @IBAction func forwardBtnPressed(_ sender: Any) {
         self.collectionView.scrollToPreviousOrNextCell(direction: .right) //Step 6
//                if(((sliderImages?.data!.count)! - 1) > indexx )
//                {
////                indexx += 1
//
//                         transition.type = CATransitionType.push
//                         transition.subtype = CATransitionSubtype.fromRight
//
//                         /*
//                          transition.type = CATransitionType.fade
//                          transition.subtype = CATransitionSubtype.fromRight
//                          */
//
//                         SlideShowViewer.layer.add(transition, forKey: kCATransition)
//                         if sliderImages?.data?.count != 0 {
//                             SlideShowViewer.kf.setImage(with: URL(string: (sliderImages!.data?[indexx])! ))
//                         }
//                         CATransaction.commit()
//                         indexx = indexx < ((sliderImages?.data!.count)!-1) ? indexx + 1 : 0
//        //        switchingInterval = 5
////                animateImageView()
//
//                }
    }
    
    @IBAction func backBtnPressed(_ sender: Any) {
        
         self.collectionView.scrollToPreviousOrNextCell(direction: .left) //Step 5
//                if( indexx > 0 )
//                               {
////                indexx -= 1
//                                transition.type = CATransitionType.push
//                                   transition.subtype = CATransitionSubtype.fromLeft
//
//                                   /*
//                                    transition.type = CATransitionType.fade
//                                    transition.subtype = CATransitionSubtype.fromRight
//                                    */
//
//                                   SlideShowViewer.layer.add(transition, forKey: kCATransition)
//                                   if sliderImages?.data?.count != 0 {
//                                       SlideShowViewer.kf.setImage(with: URL(string: (sliderImages!.data?[indexx])! ))
//                                   }
//                                   CATransaction.commit()
//                    indexx = indexx < ((sliderImages?.data!.count)!) ? indexx - 1 : 0
//        //        switchingInterval = 5
//        //        animateImageView()
//                }
    }
    //MARK:- FUNCTIONS
 
    func removeRightButton(){
        guard let subviews = self.navigationController?.navigationBar.subviews else{return}
        for view in subviews{
            if view.tag == 2{
                view.removeFromSuperview()
            }
            
        }
    }

    func initCollectionView() {
        self.collectionView.scrollInterval = 3 //Step 2
        self.collectionViewFlowLayout.scrollDirection = .horizontal
        self.collectionViewFlowLayout.minimumInteritemSpacing = 0
        self.collectionViewFlowLayout.minimumLineSpacing = 0
        self.collectionView.startScrolling() //Step 3
    }
    
    func setUpUI()
    {
       
        self.navigationController?.navigationBar.prefersLargeTitles = true
       
             let leftButton = UIButton()
                  leftButton.setImage(UIImage(systemName: "arrow.left"), for: .normal)
                  navigationController?.navigationBar.addSubview(leftButton)
                  leftButton.tag = 1
                  leftButton.frame = CGRect(x: 0 , y: 0, width: 45, height: 45)
                  leftButton.setPreferredSymbolConfiguration(.init(scale: .large), forImageIn: .normal)
                  leftButton.tintColor = UIColor(red: 91/255, green: 93/255, blue: 105/255, alpha: 1)
//                  self.navigationController?.navigationBar.topItem?.backBarButtonItem = backButton
//                  self.navigationController?.navigationBar.topItem?.backBarButtonItem?.tintColor = UIColor(red: 91/255, green: 93/255, blue: 105/255, alpha: 1)
                  leftButton.addTarget(self, action: #selector(backButtonPressed), for: .touchUpInside )
             
        
        //           rightButton.setTitle("Right Button", for: .normal)
        
        if(selectedPost?.data?[selectedIndex!].favrte_routine == "yes" )
        {
            rightButton.setImage(UIImage(systemName: "star.fill"), for: .normal)
            rightButton.tintColor = UIColor(named: "Dark Royal Blue")
            
        }
        else{
            rightButton.setImage(UIImage(systemName: "star"), for: .normal)
            rightButton.tintColor = UIColor(named: "Dark Royal Blue")
            
        }
        rightButton.setPreferredSymbolConfiguration(.init(scale: .large) , forImageIn: .normal)
        rightButton.setPreferredSymbolConfiguration( .init(weight: .medium), forImageIn: .normal)
        //           rightButton.setTitleColor(.purple, for: .normal)
        //           rightButton.addTarget(self, action: #selector(rightButtonTapped(_:)), for: .touchUpInside)
        navigationController?.navigationBar.addSubview(rightButton)
        rightButton.tag = 1
        rightButton.frame = CGRect(x: self.view.frame.width, y: 0, width: 120, height: 20)
        
        let targetView = self.navigationController?.navigationBar
        
        let trailingContraint = NSLayoutConstraint(item: rightButton, attribute:
            .trailingMargin, relatedBy: .equal, toItem: targetView,
                             attribute: .trailingMargin, multiplier: 1.0, constant: -16)
        let bottomConstraint = NSLayoutConstraint(item: rightButton, attribute: .bottom, relatedBy: .equal,
                                                  toItem: targetView, attribute: .bottom, multiplier: 1.0, constant: -6)
        rightButton.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([trailingContraint, bottomConstraint])
        
        self.navigationItem.largeTitleDisplayMode = .always
        self.navigationItem.title = "Overview"
        
//        self.navigationController?.navigationBar.backIndicatorImage = UIImage(systemName: "arrow.left")
//        self.navigationController?.navigationBar.backIndicatorTransitionMaskImage = UIImage(systemName: "arrow.left")
//        self.navigationController?.navigationBar.largeTitleTextAttributes = [NSAttributedString.Key.font: UIFont(name: "philosopher-bold", size: 34)!  , NSAttributedString.Key.foregroundColor : UIColor(named: "Dark Royal Blue")!]
//        let backButton = UIBarButtonItem()
//        backButton.title = ""
//        self.navigationController?.navigationBar.topItem?.backBarButtonItem = backButton
        self.navigationController?.navigationBar.topItem?.backBarButtonItem?.tintColor = .clear
//
        rightButton.addTarget(self, action: #selector(addToFavouritesPressed), for: .touchUpInside)
    }
    @objc func backButtonPressed()
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    @objc func addToFavouritesPressed(){
        print("favourite pressed")
        if(rightButton.currentImage == UIImage(systemName: "star"))
        {
            hitAddFavourites()
            rightButton.setImage(UIImage(systemName: "star.fill"), for: .normal)
        }
            
        else{
            hitAddFavourites()
            rightButton.setImage(UIImage(systemName: "star"), for: .normal)
        }
    }
//    func animateImageView() {
//        CATransaction.begin() //Begin the CATransaction
//
//        CATransaction.setAnimationDuration(animationDuration)
//        CATransaction.setCompletionBlock {
//            DispatchQueue.main.asyncAfter(deadline: .now() + self.switchingInterval) {[weak self] in
//                self?.animateImageView()
//            }
//        }
//
//        transition.type = CATransitionType.push
//        transition.subtype = CATransitionSubtype.fromRight
//
//        /*
//         transition.type = CATransitionType.fade
//         transition.subtype = CATransitionSubtype.fromRight
//         */
//
//        SlideShowViewer.layer.add(transition, forKey: kCATransition)
//        if sliderImages?.data?.count != 0 {
//            SlideShowViewer.kf.setImage(with: URL(string: (sliderImages!.data?[indexx])! ))
//        }
//        CATransaction.commit()
//        indexx = indexx < ((sliderImages?.data!.count)! - 1) ? indexx + 1 : 0
//    }
    
    
    func hitAddFavourites()
    {
        let jsonURLString = "\(Apis.baseURL+Apis.add_favroute)"
        guard let url = URL(string: jsonURLString) else { return }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        let parameterToSend = "user_id=" + "\(userDefaults.integer(forKey: "userID"))" + "&post_id=" + "\(selectedPost?.data?[selectedIndex!].id ?? 0)"
        request.httpBody = parameterToSend.data(using: String.Encoding.utf8)
        URLSession.shared.dataTask(with: request as URLRequest) { (data, response, error) in
            guard let data = data else { return }
            SVProgressHUD.dismiss()
            do {
                
                print("fav added")
                Toast(text: "Added to favourites").show()
                
            } catch let jsonError{
                print(jsonError.localizedDescription)
                Toast(text: "Error Adding Favourites").show()
            }
        }.resume()
    }
    
    func hitGetSliderImagesAPI()
    {
        let jsonURLString = "http://majestic-arts.com/majistic/public/api/slider_post"
        guard let url = URL(string: jsonURLString) else { return }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        let parameterToSend = "post_id=" + "\((selectedPost?.data?[selectedIndex!].id)!)"
        request.httpBody = parameterToSend.data(using: String.Encoding.utf8)
        URLSession.shared.dataTask(with: request as URLRequest) { (data, response, error) in
            guard let data = data else { return }
            SVProgressHUD.dismiss()
            
            do {
                
                self.sliderImages = try JSONDecoder().decode(SliderImages.self, from: data)
                print(self.sliderImages!)
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                    if(self.sliderImages?.status == 400)
                    {
                        
                        let alert = UIAlertController(title: "No Image found for Gallery", message: "", preferredStyle: UIAlertController.Style.alert)
                        alert.addAction(UIAlertAction(title: "Okay", style: UIAlertAction.Style.cancel , handler: nil))
                        self.present(alert, animated: true, completion: nil)
                        
                    }
                    else{
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                            
                            for each in (self.sliderImages?.data)! {
                                if(each != "null")
                                {
                                    self.imagesArr.append(each)
                                }
                            }
                            self.collectionView.reloadData()
                              self.initCollectionView()
                        }

                      
                        
//                        self.animateImageView()
                    }
                }
                
            } catch let jsonError{
                print(jsonError.localizedDescription)
            }
        }.resume()
    }
    
    
    func hitGetQuotation(){
        let jsonURLString = "http://majestic-arts.com/majistic/public/api/qoutation"
        guard let url = URL(string: jsonURLString) else { return }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        let parameterToSend = "f_name=" + (userDefaults.string(forKey: "userFname"))! + "&l_name=" + (userDefaults.string(forKey: "userLname"))! + "&email=" + (userDefaults.string(forKey: "userEmail"))! + "&phone=" + (userDefaults.string(forKey: "userPhone"))! + "&post_id=" + "\(selectedPost?.data![selectedIndex!].id ?? 0 )" + "&post_title=" + (selectedPost?.data![selectedIndex!].title)!
        //        let parameterToSend = "post_id=" + "\((selectedPost?.data?[selectedIndex!].id)!)"
        request.httpBody = parameterToSend.data(using: String.Encoding.utf8)
        URLSession.shared.dataTask(with: request as URLRequest) { (data, response, error) in
            guard let data = data else { return }
            SVProgressHUD.dismiss()
            
            do{
                
                self.quotation = try JSONDecoder().decode(QuotationModel.self, from: data)
                print(self.quotation!)
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                    if(self.quotation?.status == 400)
                    {
                        
                        let alert = UIAlertController(title: "Quotation Request Failed!", message: "Please try again later.", preferredStyle: UIAlertController.Style.alert)
                                              alert.addAction(UIAlertAction(title: "Okay", style: UIAlertAction.Style.cancel , handler: nil))
                                              self.present(alert, animated: true, completion: nil)
                        
                    }
                    else{
                          let alert = UIAlertController(title: "Quotation Request Sent!", message: "Thankyou for the request. We will contact you shortly.", preferredStyle: UIAlertController.Style.alert)
                                             alert.addAction(UIAlertAction(title: "Okay", style: UIAlertAction.Style.cancel , handler: nil))
                                             self.present(alert, animated: true, completion: nil)
                    }
                }
                
            }
            
            catch let jsonError{
                print(jsonError.localizedDescription)
            }
        }.resume()
    }

}
//MARK:- EXTENSIONS
@available(iOS 13.0, *)
extension SingleItemDetailVC : UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SingleItemTVCell", for: indexPath) as! SingleItemTVCell
        tableView.allowsSelection = false
        tableView.separatorStyle = .none
        
        cell.titleLbl.text = selectedPost?.data?[selectedIndex!].title
        cell.descriptionLbl.text = selectedPost?.data?[selectedIndex!].description
        return cell
    }
    
    
    
}
@available(iOS 13.0, *)
extension SingleItemDetailVC: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
      
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CustomImageCollectionViewCell", for: indexPath) as! CustomImageCollectionViewCell
        if(sliderImages?.data?[indexPath.row] != "null" ){
           
            imagesArr.append((sliderImages?.data?[indexPath.row])!)
           
        }
       
        cell.imageView.kf.setImage(with: URL(string: (imagesArr[indexPath.row]) ))
      
//        cell.imageView.image = self.imagesArray[indexPath.row]
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.imagesArr.count
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize.init(width: self.collectionView.frame.size.width, height: self.collectionView.frame.size.height)
    }
}


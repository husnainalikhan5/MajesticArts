//
//  SingleItemTVCell.swift
//  Majestic Arts
//
//  Created by Uzma  Amjad on 03/10/2020.
//  Copyright © 2020 HusnainKhan. All rights reserved.
//

import UIKit

class SingleItemTVCell: UITableViewCell {
    
    @IBOutlet var titleLbl: UILabel!
    @IBOutlet var descriptionLbl: UILabel!
    @IBOutlet var introLbl1: UILabel!
    @IBOutlet var introLbl2: UILabel!
    @IBOutlet var introLbl3: UILabel!
    @IBOutlet var introLbl4: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
}

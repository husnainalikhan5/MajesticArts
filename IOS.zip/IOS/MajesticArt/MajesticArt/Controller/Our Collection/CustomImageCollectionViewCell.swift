//
//  CustomImageCollectionViewCell.swift
//  MajesticArt
//
//  Created by Uzma  Amjad on 24/10/2020.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit

class CustomImageCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView:UIImageView!
    
    override func awakeFromNib() {
        self.imageView.clipsToBounds = true
        self.imageView.contentMode = .scaleAspectFill
    }
}

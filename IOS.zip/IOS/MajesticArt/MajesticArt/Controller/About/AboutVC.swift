//
//  AboutVC.swift
//  MajesticArts
//
//  Created by Uzma  Amjad on 30/09/2020.
//  Copyright © 2020 Uzma  Amjad. All rights reserved.
//

import UIKit

@available(iOS 13.0, *)
class AboutVC: UIViewController {
    
    //MARK:- OUTLETS
    @IBOutlet var tableView: UITableView!
    //MARK:- VARIABLES
    //MARK:- ARRAYS
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpUI()
        self.navigationController?.setNavigationBarHidden(false, animated: false)
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        setUpUI()
        self.navigationController?.setNavigationBarHidden(false, animated: false)
        
        
    }
    override func viewWillDisappear(_ animated: Bool) {
        self.navigationItem.title = " "
    }
    //MARK:- ACTIONS
    //MARK:- FUNCTIONS
    func setUpUI()
    {
        self.navigationController?.navigationBar.prefersLargeTitles = true
        
        self.navigationItem.largeTitleDisplayMode = .always
        self.navigationItem.title = "About Masjestic Arts"
        self.navigationItem.backBarButtonItem?.title = ""
        self.navigationController?.navigationBar.backIndicatorImage = UIImage(systemName: "arrow.left")
        self.navigationController?.navigationBar.backIndicatorTransitionMaskImage = UIImage(systemName: "arrow.left")
        self.navigationController?.navigationBar.largeTitleTextAttributes = [NSAttributedString.Key.font: UIFont(name: "philosopher-bold", size: 34)!  , NSAttributedString.Key.foregroundColor : UIColor(named: "Dark Royal Blue")!]
        let backButton = UIBarButtonItem()
        backButton.title = " "
        let leftButton = UIButton()
        leftButton.setImage(UIImage(systemName: "arrow.left"), for: .normal)
        navigationController?.navigationBar.addSubview(leftButton)
        leftButton.tag = 1
        leftButton.frame = CGRect(x: 0 , y: 0, width: 45, height: 45)
        leftButton.setPreferredSymbolConfiguration(.init(scale: .large), forImageIn: .normal)
        leftButton.tintColor = UIColor(named: "Dark Royal Blue")
        self.navigationController?.navigationBar.topItem?.backBarButtonItem = backButton
        self.navigationController?.navigationBar.topItem?.backBarButtonItem?.tintColor = UIColor(red: 91/255, green: 93/255, blue: 105/255, alpha: 1)
        leftButton.addTarget(self, action: #selector(backButtonPressed), for: .touchUpInside )
    }
    
    @objc func backButtonPressed()
    {
        print("back pressed")
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let navigationController = storyboard.instantiateViewController(withIdentifier: "NavigationController") as! UINavigationController
        navigationController.setViewControllers([storyboard.instantiateViewController(withIdentifier: "HomeVC")], animated: false)
        
        let mainViewController = storyboard.instantiateViewController(withIdentifier: "mai") as! MainViewController
        mainViewController.rootViewController = navigationController
        mainViewController.setup(type: UInt(0))
        
        let window = UIApplication.shared.delegate!.window!!
        window.rootViewController = mainViewController
        
        UIView.transition(with: window, duration: 0.3, options: [.transitionCrossDissolve], animations: nil, completion: nil)
    }
}
//MARK:- EXTENSIONS

@available(iOS 13.0, *)
extension AboutVC : UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SingleItemTVCell", for: indexPath) as! SingleItemTVCell
        cell.introLbl1.text = "Majestic Arts is a Premier Art curator par excellence with rich connections to Royalty, Art Institutions and High Net Worth Individuals. Our expertise covers extensive and diverse topics, from Indian, Islamic and Renaissance works, to Medieval and Impressionist Art among others."
        
        cell.introLbl2.text = "Majestic Arts provides a platform for buying and selling art paintings, engaging in market discussions regarding specific art pieces, and has already facilitated sales of artworks that are cumulatively worth in excess of $6 billion."
        cell.introLbl3.text = "Art has existed since the beginning of time but its relevance, form, and importance in everyday life has evolved. It is considered to be the pinnacle of human creative expression, exhibited through paintings, sculptures, and architecture. Art often tells a story, reflecting the values and aspirations of the period. The art industry is estimated to be worth approximately USD 65-70 billion. But currently, there is a major gap in reliable art authentication."
        cell.introLbl4.text = "Majestic Arts addresses this requirement by outsourcing the authentication process to a world-renowned reliable company. which has far more experience and database with modern technology than most of the contemporary authenticators. Majestic Arts’ unique authentication arrangements with a unique business models, combined with its unfettered access within the art world make it the most reliable ideal choice."
        cell.titleLbl.text = "Introduction"
        cell.selectionStyle = .none
        
        return cell
    }
    
    
}

//
//  SplashVC.swift
//  MajesticArt
//
//  Created by Uzma  Amjad on 19/10/2020.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit

class SplashVC: UIViewController {
    
    @IBOutlet var logoView: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    override func viewWillAppear(_ animated: Bool) {
        logoView.alpha = 0.0
        
        Timer.scheduledTimer(withTimeInterval: 0.5 , repeats: false) { (timer) in
            UIView.animate(withDuration: 1.5, animations: {
                self.logoView.alpha = 1.0
            }) { (done) in
                let userID = userDefaults.integer(forKey: "userID")
                if(userID != 0)
                {
                    self.moveToDashboard()
                }
                else{
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
                    self.navigationController?.pushViewController(vc, animated: false)
                }
            }
            
        }
    }
    
    func moveToDashboard(){
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let navigationController = storyboard.instantiateViewController(withIdentifier: "NavigationController") as! UINavigationController
        navigationController.setViewControllers([storyboard.instantiateViewController(withIdentifier: "HomeVC")], animated: false)
        
        let mainViewController = storyboard.instantiateViewController(withIdentifier: "mai") as! MainViewController
        mainViewController.rootViewController = navigationController
        mainViewController.setup(type: UInt(0))
        
        let window = UIApplication.shared.delegate!.window!!
        window.rootViewController = mainViewController
        
        UIView.transition(with: window, duration: 0.3, options: [.transitionCrossDissolve], animations: nil, completion: nil)
    }
    
}

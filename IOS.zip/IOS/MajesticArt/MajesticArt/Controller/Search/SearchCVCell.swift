//
//  SearchCVCell.swift
//  MajesticArts
//
//  Created by Uzma  Amjad on 01/10/2020.
//  Copyright © 2020 Uzma  Amjad. All rights reserved.
//

import UIKit

class SearchCVCell: UICollectionViewCell {
    
    @IBOutlet var itemTitle: UILabel!
    @IBOutlet var itemImg: UIImageView!
    @IBOutlet var itemSubTitle: UILabel!
}

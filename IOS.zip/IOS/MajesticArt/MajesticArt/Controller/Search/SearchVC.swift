//
//  SearchVC.swift
//  MajesticArts
//
//  Created by Uzma  Amjad on 30/09/2020.
//  Copyright © 2020 Uzma  Amjad. All rights reserved.
//

import UIKit
import SVProgressHUD

class SearchVC: UIViewController {
    
    //MARK:- OUTLETS
    
    
    @IBOutlet var collectionView: UICollectionView!
    @IBOutlet var searchBar: UISearchBar!
    
    //MARK:- VARIABLES
    var allPosts : PostModel?
    var filteredArray : PostModel?
    //MARK:- ARRAYS
    var itemImagesArr : [UIImage] = [UIImage(named: "sample image 1")! , UIImage(named: "sample image 2")! , UIImage(named: "sample image 3")! , UIImage(named: "sample image 4")! , UIImage(named: "sample image 5")! , UIImage(named: "sample image 6")!]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        SVProgressHUD.show()
        searchBar.delegate = self
        
        UISetup()
        hitAllPostsAPI()
        
        //        
        
    }
    
    //MARK:- ACTIONS
    //MARK:- FUNCTIONS
    func hitAllPostsAPI()
    {
        let jsonURLString = "\(Apis.baseURL+Apis.collection_posts)"
        guard let url = URL(string: jsonURLString) else { return }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        let parameterToSend = "user_id=" + "\(userDefaults.integer(forKey: "userID"))"
        request.httpBody = parameterToSend.data(using: String.Encoding.utf8)
        URLSession.shared.dataTask(with: request as URLRequest) { (data, response, error) in
            guard let data = data else { return }
            SVProgressHUD.dismiss()
            do {
                self.allPosts = try JSONDecoder().decode(PostModel.self, from: data)
                print(self.allPosts ?? "")
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                    self.filteredArray = self.allPosts
                    self.collectionView.reloadData()
                }
                
            } catch let jsonError{
                print(jsonError.localizedDescription)
            }
        }.resume()
    }
    
    func UISetup(){
        
        if let textField = searchBar.value(forKey: "searchField") as? UITextField {
            textField.backgroundColor = .white
            textField.font = UIFont(name: "Lato-Regular", size: 18)
            
            //textField.textColor = #colorLiteral(red: 0.4, green: 0.2274509804, blue: 0.7215686275, alpha: 1)
            //textField.tintColor = #colorLiteral(red: 0.8117647059, green: 0.9215686275, blue: 0.4196078431, alpha: 1)
            // And so on...
            
            let backgroundView = textField.subviews.first
            if #available(iOS 11.0, *) { // If `searchController` is in `navigationItem`
                backgroundView?.backgroundColor = UIColor.white.withAlphaComponent(0.3) //Or any transparent color that matches with the `navigationBar color`
                backgroundView?.subviews.forEach({ $0.removeFromSuperview() }) // Fixes an UI bug when searchBar appears or hides when scrolling
            }
            backgroundView?.layer.cornerRadius = 10.5
            backgroundView?.layer.masksToBounds = true
            //Continue changing more properties...
        }
    }

}
//MARK:- EXTENSIONS


extension SearchVC : UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.width/2, height: collectionView.frame.width/2 + 50 ) 
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return filteredArray?.data?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SearchCVCell", for: indexPath) as? SearchCVCell
        //
        cell?.itemImg.kf.setImage(with: URL(string: (filteredArray?.data?[indexPath.row].caption_image)!))
        cell?.itemTitle.text = filteredArray?.data?[indexPath.row].title
        cell?.itemSubTitle.text = filteredArray?.data?[indexPath.row].subtitle
        return cell!
        
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if #available(iOS 13.0, *) {
            let vc = storyboard?.instantiateViewController(identifier: "SingleItemDetailVC") as! SingleItemDetailVC
            vc.selectedIndex = indexPath.row
            vc.selectedPost = allPosts
            self.navigationController?.pushViewController(vc, animated: true)
        } else {
            // Fallback on earlier versions
        }
        
    }
    
    
}
// MARK: Search Bar Delegate Methods

extension SearchVC: UISearchBarDelegate
{
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        guard !searchText.isEmpty else{
            filteredArray?.data = allPosts?.data
            collectionView.reloadData()
            return
            
        }
        filteredArray?.data = allPosts?.data?.filter({ (PostModel) -> Bool in
            guard let text = searchBar.text else {return false}
            return (PostModel.title?.lowercased().contains(text.lowercased()))!
        })
        collectionView.reloadData()
    }
    
    func searchBar(_ searchBar: UISearchBar, selectedScopeButtonIndexDidChange selectedScope: Int) {
    }
}

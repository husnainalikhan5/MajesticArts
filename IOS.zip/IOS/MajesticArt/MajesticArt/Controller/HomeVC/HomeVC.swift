//
//  HomeVC.swift
//  MajesticArt
//
//  Created by apple on 10/5/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit
import LZViewPager

class HomeVC: UIViewController {
    
    //MARK:- OUTLETS
    //    @IBOutlet var viewPager: UIView!
    
    @IBOutlet weak var viewPager: LZViewPager!
    @IBOutlet var forYouLine: UIView!
    @IBOutlet var searchLine: UIView!
    @IBOutlet var favouriteLine: UIView!
    
    @IBOutlet var foryouBtn: UIButton!
    @IBOutlet var searchBtn: UIButton!
    @IBOutlet var favouriteBtn: UIButton!
    
    //MARK:- VARIABLES
    
    
    public static var segueView: UIView!
    //MARK:- ARRAYS
    private var subControllers:[UIViewController] = []
    var names: [String] = ["For You","Search", "Favourite"]
    override func viewDidLoad() {
        
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        
        super.viewDidLoad()
        HomeVC.segueView = self.view
        self.forYouLine.isHidden = false
        self.searchLine.isHidden = true
        self.favouriteLine.isHidden = true
        viewPager.dataSource = self
        viewPager.delegate = self
        viewPager.hostController = self
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let forYouVC = storyboard.instantiateViewController(withIdentifier: "ForYouVC") as! ForYouVC
        
        
        let searchVC : UIViewController = storyboard.instantiateViewController(withIdentifier: "SearchVC") as UIViewController
        let favouriteVC = storyboard.instantiateViewController(withIdentifier: "FavouriteVC") as! FavouriteVC
        subControllers = [forYouVC, searchVC,favouriteVC ]
        viewPager.reload()
        viewPager.select(index : 0 , animated : true)
        
    }
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        
    }
    
    //MARK:- ACTIONS
    
    @IBAction func sideMenuBtnPressed(_ sender: Any) {
        print("Clicked")
        sideMenuController?.showLeftView(animated: true, completionHandler: nil)
        
    }
    @IBAction func forYouBtnPressed(_ sender: Any) {
        
        viewPager.select(index: 0)
        self.foryouBtn.setTitleColor(UIColor(named: "Dark Royal Blue"), for: .normal)
        self.searchBtn.setTitleColor(UIColor(named: "Mustard Color") , for: .normal)
        self.favouriteBtn.setTitleColor(UIColor(named: "Mustard Color"), for: .normal)
        self.forYouLine.isHidden = false
        self.searchLine.isHidden = true
        self.favouriteLine.isHidden = true
        
        
    }
    @IBAction func searchBtnPressed(_ sender: Any) {
        
        viewPager.select(index: 1)
        self.foryouBtn.setTitleColor(UIColor(named: "Mustard Color"), for: .normal)
        self.searchBtn.setTitleColor(UIColor(named: "Dark Royal Blue") , for: .normal)
        self.favouriteBtn.setTitleColor(UIColor(named: "Mustard Color"), for: .normal)
        self.forYouLine.isHidden = true
        self.searchLine.isHidden = false
        self.favouriteLine.isHidden = true
        
    }
    @IBAction func favouriteBtnPressed(_ sender: Any) {
        
        viewPager.select(index: 2)
        self.foryouBtn.setTitleColor(UIColor(named: "Mustard Color"), for: .normal)
        self.searchBtn.setTitleColor(UIColor(named: "Mustard Color") , for: .normal)
        self.favouriteBtn.setTitleColor(UIColor(named: "Dark Royal Blue"), for: .normal)
        self.forYouLine.isHidden = true
        self.searchLine.isHidden = true
        self.favouriteLine.isHidden = false
        
    }
    
    //MARK:- FUNCTIONS
    
}

//MARK:- EXTENSIONS


extension HomeVC : LZViewPagerDelegate, LZViewPagerDataSource {
    func numberOfItems() -> Int {
        return self.subControllers.count
    }
    
    func controller(at index: Int) -> UIViewController {
        return subControllers[index]
    }
    func shouldShowIndicator() -> Bool {
        true
    }
    func heightForHeader() -> CGFloat {
        0
    }
    func button(at index: Int) -> UIButton {
        let button = UIButton()
        button.titleLabel?.font = UIFont.systemFont(ofSize: 16)
        button.setTitleColor(UIColor.black, for: .selected)
        button.setTitleColor(UIColor.black.withAlphaComponent(0.2), for: .normal)
        
        
        return button
    }
    func willTransition(to index: Int) {
        
        print("Current index before transition: \(viewPager.currentIndex ?? -1)")
        
    }
    
    func didTransition(to index: Int) {
        if viewPager.currentIndex == 0 {
            DispatchQueue.main.async {
                
            }
        }
        else if viewPager.currentIndex == 1 {
            DispatchQueue.main.async {
                
            }
            
        }
        else if viewPager.currentIndex == 2 {
            DispatchQueue.main.async {
                
                
            }
            
        }
        print("Current index after transition 2: \(viewPager.currentIndex ?? -1)")
    }
    
    func didSelectButton(at index: Int) {
        print("Current index before transition: \(viewPager.currentIndex ?? -1)")
        print("Current index after transition: \(index)")
        
    }
}


extension UIViewController {
    func embed(_ viewController:UIViewController, inView view:UIView){
        viewController.willMove(toParent: self)
        viewController.view.frame = view.bounds
        view.addSubview(viewController.view)
        self.addChild(viewController)
        viewController.didMove(toParent: self)
    }
}
